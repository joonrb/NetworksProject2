#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <sys/time.h>
#include <errno.h>

#include "rdt_sender.h"

int next_seqno = 0;
int send_base = 0;
int sockfd, serverlen;
struct sockaddr_in serveraddr;
FILE *fp;
int done_reading = 0;
int eot_sent = 0;
int eot_ack_received = 0;

WindowEntry window[SEQ_NUM_SPACE];  // Window entries with larger sequence number space

int main(int argc, char **argv) {
    int portno;
    char *hostname;
    char buffer[DATA_SIZE];
    struct timeval tv;

    if (argc != 4) {
        fprintf(stderr,"usage: %s <hostname> <port> <FILE>\n", argv[0]);
        exit(0);
    }
    hostname = argv[1];
    portno = atoi(argv[2]);
    fp = fopen(argv[3], "rb");
    if (fp == NULL) {
        error(argv[3]);
    }

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0)
        error("ERROR opening socket");

    // Set socket timeout
    tv.tv_sec = 0;
    tv.tv_usec = 100000;  // 100 milliseconds
    if (setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv)) < 0) {
        perror("setsockopt");
    }

    bzero((char *) &serveraddr, sizeof(serveraddr));
    serverlen = sizeof(serveraddr);

    if (inet_aton(hostname, &serveraddr.sin_addr) == 0) {
        fprintf(stderr,"ERROR, invalid host %s\n", hostname);
        exit(0);
    }

    serveraddr.sin_family = AF_INET;
    serveraddr.sin_port = htons(portno);

    memset(window, 0, sizeof(window));

    while (1) {
        // Send packets while window is not full and data remains to be sent
        while (((next_seqno - send_base + SEQ_NUM_SPACE) % SEQ_NUM_SPACE) < WINDOW_SIZE && !done_reading) {
            int len = fread(buffer, 1, DATA_SIZE, fp);
            if (len <= 0) {
                done_reading = 1;
                break;
            }

            tcp_packet *pkt = make_packet(len);
            memcpy(pkt->data, buffer, len);
            pkt->hdr.seqno = next_seqno;
            pkt->hdr.data_size = len;

            int idx = next_seqno % SEQ_NUM_SPACE;

            // Store the packet in the window buffer
            window[idx].pkt = pkt;
            window[idx].acked = 0;
            gettimeofday(&window[idx].sent_time, NULL);

            send_data_packet(pkt, len);

            fprintf(stderr, "Sent packet with seqno %d, data_size %d\n",
                    pkt->hdr.seqno, pkt->hdr.data_size);

            next_seqno = (next_seqno + 1) % SEQ_NUM_SPACE;
        }

        // Set up timeout for select
        struct timeval timeout;
        timeout.tv_sec = 0;
        timeout.tv_usec = 100000; // 100 milliseconds

        fd_set readfds;
        FD_ZERO(&readfds);
        FD_SET(sockfd, &readfds);

        int n = select(sockfd + 1, &readfds, NULL, NULL, &timeout);

        if (n < 0) {
            if (errno == EINTR) {
                continue;
            } else {
                perror("select");
            }
        } else if (n == 0) {
            // Timeout occurred
            check_timeouts();
        } else {
            if (FD_ISSET(sockfd, &readfds)) {
                // Receive ACKs
                char ackbuf[1024];
                struct sockaddr_in from;
                socklen_t fromlen = sizeof(from);
                int ack_len = recvfrom(sockfd, ackbuf, sizeof(ackbuf), 0,
                                       (struct sockaddr *)&from, &fromlen);
                if (ack_len < 0) {
                    if (errno == EINTR) {
                        continue;
                    } else {
                        perror("recvfrom");
                    }
                } else {
                    // Process ACK
                    if (ack_len < TCP_HDR_SIZE) {
                        fprintf(stderr, "Received ACK packet too small\n");
                        continue;
                    }
                    tcp_packet *ack_pkt = (tcp_packet *)ackbuf;

                    convert_header_from_network_order(ack_pkt);

                    if (ack_pkt->hdr.ctr_flags == EOT_PACKET) {
                        fprintf(stderr, "Received EOT ACK\n");
                        eot_ack_received = 1;
                        break;
                    } else {
                        int ackno = ack_pkt->hdr.ackno;
                        fprintf(stderr, "Received ACK for seqno %d\n", ackno - 1);

                        if (((ackno - send_base + SEQ_NUM_SPACE) % SEQ_NUM_SPACE) < WINDOW_SIZE) {
                            int idx = (ackno - 1) % SEQ_NUM_SPACE;
                            if (window[idx].pkt != NULL && !window[idx].acked) {
                                window[idx].acked = 1;
                                // Free the packet
                                free(window[idx].pkt);
                                window[idx].pkt = NULL;
                            }

                            // Advance send_base
                            while (window[send_base % SEQ_NUM_SPACE].acked &&
                                   send_base != next_seqno) {
                                window[send_base % SEQ_NUM_SPACE].acked = 0;
                                send_base = (send_base + 1) % SEQ_NUM_SPACE;
                            }
                        } else {
                            fprintf(stderr, "Received ACK for packet outside window\n");
                        }
                    }
                }
            }
        }

        // Check for timeouts
        check_timeouts();

        // Check if all data has been sent and acknowledged
        if (done_reading && send_base == next_seqno && !eot_sent) {
            // Send EOT packet
            tcp_packet *eot_pkt = make_packet(0);
            eot_pkt->hdr.ctr_flags = EOT_PACKET;
            eot_pkt->hdr.seqno = next_seqno;

            send_data_packet(eot_pkt, 0);

            fprintf(stderr, "Sent EOT packet with seqno %d\n", next_seqno);

            eot_sent = 1;
        }

        if (eot_sent && eot_ack_received) {
            fprintf(stderr, "All data sent and acknowledged. Exiting.\n");
            break;
        }
    }

    fclose(fp);

    // Clean up remaining packets
    for (int i = 0; i < SEQ_NUM_SPACE; i++) {
        if (window[i].pkt != NULL) {
            free(window[i].pkt);
        }
    }

    return 0;
}

/* Function to convert packet header from network byte order to host byte order */
void convert_header_from_network_order(tcp_packet *pkt) {
    pkt->hdr.seqno = ntohl(pkt->hdr.seqno);
    pkt->hdr.ackno = ntohl(pkt->hdr.ackno);
    pkt->hdr.ctr_flags = ntohl(pkt->hdr.ctr_flags);
    pkt->hdr.data_size = ntohl(pkt->hdr.data_size);
}

/* Function to convert packet header from host byte order to network byte order */
void convert_header_to_network_order(tcp_packet *pkt) {
    pkt->hdr.seqno = htonl(pkt->hdr.seqno);
    pkt->hdr.ackno = htonl(pkt->hdr.ackno);
    pkt->hdr.ctr_flags = htonl(pkt->hdr.ctr_flags);
    pkt->hdr.data_size = htonl(pkt->hdr.data_size);
}

/* Function to send a data packet */
void send_data_packet(tcp_packet *pkt, int data_size) {
    convert_header_to_network_order(pkt);
    if (sendto(sockfd, pkt, TCP_HDR_SIZE + data_size, 0,
               (const struct sockaddr *)&serveraddr, serverlen) < 0) {
        error("sendto");
    }
    convert_header_from_network_order(pkt);
}

void check_timeouts() {
    struct timeval now;
    gettimeofday(&now, NULL);

    int seqno_to_retransmit = -1;

    for (int i = send_base; i != next_seqno; i = (i + 1) % SEQ_NUM_SPACE) {
        int idx = i % SEQ_NUM_SPACE;
        if (window[idx].pkt != NULL && !window[idx].acked) {
            // Calculate time elapsed since the packet was sent
            long elapsed = (now.tv_sec - window[idx].sent_time.tv_sec) * 1000 +
                           (now.tv_usec - window[idx].sent_time.tv_usec) / 1000;
            if (elapsed >= TIMEOUT) {
                seqno_to_retransmit = i;
                break;  // Retransmit only the earliest timed-out packet
            }
        }
    }

    if (seqno_to_retransmit != -1) {
        // Retransmit the packet
        int idx = seqno_to_retransmit % SEQ_NUM_SPACE;
        tcp_packet *pkt = window[idx].pkt;

        int data_size = pkt->hdr.data_size; // Store data_size before converting

        send_data_packet(pkt, data_size);

        // Update sent_time
        gettimeofday(&window[idx].sent_time, NULL);

        fprintf(stderr, "Retransmitted packet with seqno %d\n", pkt->hdr.seqno);
    }
}