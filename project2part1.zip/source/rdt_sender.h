#ifndef RDT_SENDER_H_INCLUDED
#define RDT_SENDER_H_INCLUDED

#define WINDOW_SIZE 10
#define SEQ_NUM_SPACE 256 
#define TIMEOUT 500        

#include "packet.h"
#include "common.h"

typedef struct {
    tcp_packet *pkt;
    int acked;
    struct timeval sent_time;
} WindowEntry;

void convert_header_from_network_order(tcp_packet *pkt);
void convert_header_to_network_order(tcp_packet *pkt);
void send_data_packet(tcp_packet *pkt, int data_size);
void check_timeouts();

#endif